import logging
from flask import Flask, jsonify, render_template, request, redirect, url_for, send_from_directory, session
from werkzeug.utils import secure_filename
import os
import json
import asyncio
import time
import hashlib
import fitz  # PyMuPDF
from datetime import datetime, timezone
from typing import List, Optional
from pathlib import Path
from dotenv import load_dotenv

from neo4j import GraphDatabase
from modules.neo4j_handler import Neo4jHandler
from modules import metadata_extractors  # async enrich_text(text, page_count)
from modules.ollama_handler import OllamaHandler
from routes import user, admin  # Add admin import

# -----------------------------
# App config
# -----------------------------
app = Flask(__name__)

#ollama_handler = OllamaHandler(model="llama3")
# Configuration
app.config.update(
    METADATA_DIR=os.path.join(os.path.dirname(__file__), 'metadata'),
    UPLOAD_FOLDER=os.path.join(os.path.dirname(__file__), 'uploads'),
    SITEMAP_DIR=os.path.join(os.path.dirname(__file__), 'sitemaps'),
    SECRET_KEY='your-secret-key-here',
    MAX_CONTENT_LENGTH=16 * 1024 * 1024  # 16MB max file size
)

# Create required directories
for directory in [app.config['METADATA_DIR'], 
                 app.config['UPLOAD_FOLDER'], 
                 app.config['SITEMAP_DIR']]:
    os.makedirs(directory, exist_ok=True)

# Register blueprints
app.register_blueprint(admin.bp)
app.register_blueprint(user.bp)

# Hardcoded paths
ROOT_FOLDER = r"C:\demo1\azurevmollama\aniUItest\KM_folder"
METADATA_DIR = r"C:\demo1\azurevmollama\aniUItest\metadata"
SITEMAP_DIR = r"C:\demo1\azurevmollama\aniUItest\sitemaps"
UPLOADS_DIR = os.path.join(ROOT_FOLDER, "uploaded")           # for admin folder uploads (multiple files)
USER_RFP_DIR = os.path.join(ROOT_FOLDER, "user_rfp_uploads")  # for user RFP uploads (single file)

os.makedirs(SITEMAP_DIR, exist_ok=True)
os.makedirs(METADATA_DIR, exist_ok=True)
os.makedirs(UPLOADS_DIR, exist_ok=True)
os.makedirs(USER_RFP_DIR, exist_ok=True)

# Replace the hardcoded Neo4j credentials with config from environment variables
load_dotenv()

# Neo4j configuration
NEO4J_URI = os.getenv('NEO4J_URI', 'bolt://localhost:7687')
NEO4J_USER = os.getenv('NEO4J_USER', 'neo4j')
NEO4J_PASSWORD = os.getenv('NEO4J_PASSWORD', '3H7lgm8ISs_VCRwxjxnAioQrLzuP4PgZOEfxxFI7QWI')

# Add near the top of the file, after imports
def init_neo4j():
    try:
        driver = GraphDatabase.driver(NEO4J_URI, auth=(NEO4J_USER, NEO4J_PASSWORD))
        # Test the connection
        with driver.session() as session:
            session.run("MATCH (n) RETURN n LIMIT 1")
        return driver
    except Exception as e:
        app.logger.error(f"Failed to connect to Neo4j: {str(e)}")
        return None

# Replace the direct driver initialization with:
driver = init_neo4j()
if driver:
    handler = Neo4jHandler(driver)
else:
    app.logger.warning("Neo4j connection failed - graph features will be disabled")
    handler = None

ollama_handler = OllamaHandler()

# -----------------------------
# Utility functions
# -----------------------------
def infer_tags(path: str):
    parts = path.replace("\\", "/").split("/")
    return {
        "domain": parts[0] if len(parts) > 0 else "Unknown",
        "region": parts[1] if len(parts) > 1 else "Unknown",
        "client": parts[2] if len(parts) > 2 else "Unknown"
    }

def file_hash(path: str) -> str:
    with open(path, "rb") as f:
        return hashlib.md5(f.read()).hexdigest()

def detect_language(text: str) -> str:
    try:
        return detect_language(text)
    except Exception:
        return "unknown"

def generate_quick_overview(text: str, max_chars: int = 500) -> str:
    return text.strip().replace("\n", " ")[:max_chars]

# Add this utility function at the top with other utility functions
def safe_read_json(file_path):
    try:
        if not os.path.exists(file_path):
            return []
            
        with open(file_path, 'r', encoding='utf-8', errors='replace') as f:
            content = f.read()
            # Clean any potential BOM or invalid characters
            content = content.encode('utf-8', errors='replace').decode('utf-8')
            return json.loads(content)
    except json.JSONDecodeError as e:
        app.logger.error(f"JSON decode error in {file_path}: {str(e)}")
        return []
    except Exception as e:
        app.logger.error(f"Error reading JSON from {file_path}: {str(e)}")
        return []

# -----------------------------
# Sitemap builder
# -----------------------------
def build_sitemap(root_folder: str) -> List[dict]:
    entries = []
    try:
        for dirpath, _, filenames in os.walk(root_folder):
            for fname in filenames:
                try:
                    ext = os.path.splitext(fname)[1].lower()
                    if ext != ".pdf":
                        continue
                    full_path = os.path.join(dirpath, fname)
                    rel_path = os.path.relpath(full_path, root_folder)
                    tags = infer_tags(rel_path)
                    stat = os.stat(full_path)
                    
                    # Safe PDF opening
                    try:
                        with fitz.open(full_path) as doc:
                            page_count = doc.page_count
                            text = doc[0].get_text("text") if page_count > 0 else ""
                    except Exception as e:
                        print(f"Error reading PDF {fname}: {str(e)}")
                        page_count = 0
                        text = ""
                    
                    entries.append({
                        "id": file_hash(full_path)[:12],
                        "filename": fname,
                        "absolute_path": full_path,
                        "relative_path": rel_path,
                        "extension": ext,
                        "domain": tags["domain"],
                        "region": tags["region"],
                        "client": tags["client"],
                        "file_size_bytes": stat.st_size,
                        "last_modified": datetime.fromtimestamp(stat.st_mtime).isoformat(),
                        "page_count": page_count,
                        "quick_overview": generate_quick_overview(text)
                    })
                except Exception as e:
                    print(f"Error processing file {fname}: {str(e)}")
                    continue
    except Exception as e:
        print(f"Error walking directory {root_folder}: {str(e)}")
    return entries

# -----------------------------
# PDF metadata extractor
# -----------------------------
def extract_pdf_text(file_path: str) -> str:
    text_chunks = []
    try:
        with fitz.open(file_path) as doc:
            for page in doc:
                try:
                    text = page.get_text("text")
                    # Clean and normalize text
                    text = text.encode('utf-8', errors='replace').decode('utf-8')
                    text_chunks.append(text)
                except UnicodeDecodeError:
                    text_chunks.append("[Error: Unable to decode page text]")
    except Exception as e:
        print(f"Error processing PDF {file_path}: {str(e)}")
        return ""
    return "\n".join(text_chunks)

def extract_pdf_metadata(file_path: str) -> dict:
    props = {}
    try:
        stat = os.stat(file_path)
        props["file_size_bytes"] = stat.st_size
        props["created_time"] = datetime.fromtimestamp(stat.st_ctime).isoformat()
        props["modified_time"] = datetime.fromtimestamp(stat.st_mtime).isoformat()
    except Exception as e:
        props["fs_meta_error"] = str(e)

    try:
        with fitz.open(file_path) as doc:
            props["page_count"] = doc.page_count
            props["pdf_metadata"] = doc.metadata or {}
    except Exception as e:
        props["pdf_meta_error"] = str(e)

    return props

async def process_pdf(entry: dict, root_folder: str, preview_chars: int = 1500) -> dict:
    full_path = os.path.join(root_folder, entry["relative_path"])
    start = time.time()
    try:
        text = await asyncio.to_thread(extract_pdf_text, full_path)
        props = await asyncio.to_thread(extract_pdf_metadata, full_path)
        lang = detect_language(text)
        hash_val = file_hash(full_path)
        enrichment = await metadata_extractors.enrich_text(text, props.get("page_count", 0))
    except Exception as e:
        return {"error": str(e), "filename": entry.get("filename", "unknown")}

    elapsed = round(time.time() - start, 3)

    return {
        "id": hash_val[:12],
        "filename": entry["filename"],
        "relative_path": entry["relative_path"],
        "extension": entry["extension"],
        "tags": {
            "domain": entry["domain"],
            "region": entry["region"],
            "client": entry["client"]
        },
        "file_size_bytes": props.get("file_size_bytes"),
        "last_modified": props.get("modified_time"),
        "page_count": props.get("page_count"),
        "content_length": len(text),
        "pdf_metadata": props.get("pdf_metadata"),
        "hash": hash_val,
        "language": lang,
        "ingested_at": datetime.now(timezone.utc).isoformat(),
        "content_preview": text[:preview_chars],
        "overview_summary": enrichment["content_summary"]["summary"],
        "content_summary": enrichment["content_summary"],
        "classification": enrichment["classification"],
        "industry_tags": enrichment["industry_tags"],
        "entities": enrichment["entities"],
        "extraction_time_sec": elapsed
    }

async def process_all_pdfs(sitemap: List[dict], root_folder: str):
    tasks = [process_pdf(entry, root_folder) for entry in sitemap]
    return await asyncio.gather(*tasks)


@app.route("/view_metadata", methods=["GET"])
def view_metadata():
    metadata_path = os.path.join(METADATA_DIR, "metadata.json")
    metadata = safe_read_json(metadata_path)
    return render_template("metadata.html", metadata=metadata)
# -----------------------------
# Auth (basic placeholder)
# -----------------------------
@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "GET":
        return render_template("login.html")
    # POST
    username = request.form.get("username", "")
    password = request.form.get("password", "")
    # Very basic role routing (placeholder)
    if username.lower().startswith("admin"):
        session["role"] = "admin"
        return redirect(url_for("admin_panel"))
    else:
        session["role"] = "user"
        return redirect(url_for("user_panel"))

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("home"))

# -----------------------------
# Dashboard and panels
# -----------------------------
@app.route("/")
def home():
    return render_template('dashboard.html')  # or home.html depending on which you want to use

@app.route("/user", methods=["GET"])
def user_panel():
    try:
        metadata_path = os.path.join(METADATA_DIR, "metadata.json")
        metadata = safe_read_json(metadata_path)
        
        # Initialize graph summary
        graph_summary = {
            'total_docs': len(metadata),
            'tech_categories': {},
            'domains': {},
            'industry_sectors': {}
        }
        
        # Process metadata
        for doc in metadata:
            if isinstance(doc, dict):
                # Technology categories
                if 'classification' in doc:
                    for tech in doc['classification'].get('technologies', []):
                        graph_summary['tech_categories'][tech] = \
                            graph_summary['tech_categories'].get(tech, 0) + 1
                
                # Domain categories
                if 'tags' in doc and 'domain' in doc['tags']:
                    domain = doc['tags']['domain']
                    graph_summary['domains'][domain] = \
                        graph_summary['domains'].get(domain, 0) + 1

                # Industry sectors
                for tag in doc.get('industry_tags', []):
                    graph_summary['industry_sectors'][tag] = \
                        graph_summary['industry_sectors'].get(tag, 0) + 1
        
        return render_template("user.html", 
                            metadata=metadata,
                            graph_summary=graph_summary)
    except Exception as e:
        app.logger.error(f"Error in user panel: {str(e)}")
        return render_template("error.html", error=str(e)), 500

# -----------------------------
# Admin actions
# -----------------------------
@app.route("/ingest", methods=["GET"])
def ingest():
    try:
        # Build sitemap
        sitemap = build_sitemap(ROOT_FOLDER)
        sitemap_path = os.path.join(SITEMAP_DIR, "sitemap.json")
        with open(sitemap_path, "w", encoding="utf-8") as f:
            json.dump(sitemap, f, indent=2, ensure_ascii=False)

        # Async processing
        results = asyncio.run(process_all_pdfs(sitemap, ROOT_FOLDER))
        
        # Clean results before saving
        cleaned_results = []
        for doc in results:
            if isinstance(doc, dict):
                # Ensure all text fields are properly encoded
                for key, value in doc.items():
                    if isinstance(value, str):
                        doc[key] = value.encode('utf-8', errors='replace').decode('utf-8')
                cleaned_results.append(doc)

        metadata_path = os.path.join(METADATA_DIR, "metadata.json")
        with open(metadata_path, "w", encoding="utf-8") as f:
            json.dump(cleaned_results, f, indent=2, ensure_ascii=False)

        # Push to Neo4j
        for doc in cleaned_results:
            if "id" in doc and "filename" in doc and "error" not in doc:
                handler.create_document_graph(doc)

        preview = json.dumps(cleaned_results[:1], indent=2, ensure_ascii=False)
        return render_template(
            "results.html",
            files_processed=len(cleaned_results),
            sitemap_file=sitemap_path,
            metadata_file=metadata_path,
            metadata_preview=preview
        )
    except Exception as e:
        app.logger.error(f"Ingest error: {str(e)}")
        return render_template("error.html", error=str(e)), 500

@app.route("/view_graph", methods=["GET"])
def view_graph():
    with driver.session() as session_db:
        result = session_db.run("""
            MATCH (a)-[r]->(b)
            RETURN a, r, b LIMIT 200
        """)
        nodes, edges = [], []
        seen = set()

        def node_color(label):
            colors = {
                "Document": "#1f77b4",   # blue
                "Client": "#2ca02c",     # green
                "Region": "#ff7f0e",     # orange
                "Domain": "#9467bd",     # purple
                "Industry": "#8c564b",   # brown
                "Technology": "#17becf", # teal
                "Partner": "#d62728",    # red
                "Product": "#bcbd22"     # yellow-green
            }
            return colors.get(label, "#7f7f7f")  # default grey

        for record in result:
            a, r, b = record["a"], record["r"], record["b"]

            if a.id not in seen:
                label_a = list(a.labels)[0] if a.labels else "Node"
                nodes.append({
                    "id": a.id,
                    "label": label_a,
                    "title": dict(a),
                    "color": node_color(label_a)
                })
                seen.add(a.id)

            if b.id not in seen:
                label_b = list(b.labels)[0] if b.labels else "Node"
                nodes.append({
                    "id": b.id,
                    "label": label_b,
                    "title": dict(b),
                    "color": node_color(label_b)
                })
                seen.add(b.id)

            edges.append({
                "from": a.id,
                "to": b.id,
                "label": r.type
            })

    return render_template(
        "graph.html",
        nodes=json.dumps(nodes),
        edges=json.dumps(edges)
    )

@app.route("/upload_folder", methods=["POST"])
def upload_folder():
    """
    Handles folder upload from admin panel
    """
    files = request.files.getlist("folder")
    if not files:
        return jsonify({"status": "error", "message": "No files selected"}), 400

    try:
        saved_count = 0
        for f in files:
            if f.filename:  # Skip if filename is empty
                filename = secure_filename(f.filename)
                # Preserve folder structure
                filepath = os.path.join(UPLOADS_DIR, filename)
                os.makedirs(os.path.dirname(filepath), exist_ok=True)
                f.save(filepath)
                saved_count += 1

        return jsonify({
            "status": "success",
            "message": f"Folder uploaded successfully",
            "files_processed": saved_count
        })

    except Exception as e:
        app.logger.error(f"Upload error: {str(e)}")
        return jsonify({
            "status": "error",
            "message": "Error during upload"
        }), 500

# -----------------------------
# User actions
# -----------------------------
@app.route("/upload_rfp", methods=["POST"])
def upload_rfp():
    """
    Handles user RFP upload (single PDF).
    """
    file = request.files.get("rfp_file")
    if file is None or file.filename == "":
        return jsonify({"status": "no_file"}), 400
    filename = secure_filename(file.filename)
    if not filename.lower().endswith(".pdf"):
        return jsonify({"status": "invalid_type", "message": "Only PDF allowed"}), 400
    dest_path = os.path.join(USER_RFP_DIR, filename)
    file.save(dest_path)
    return jsonify({"status": "success", "saved_to": dest_path})

@app.route("/chatbot", methods=["POST"])
async def chatbot():
    try:
        if not request.is_json:
            return jsonify({"error": "Content-Type must be application/json"}), 400
            
        data = request.get_json()
        if not data or "message" not in data:
            return jsonify({"error": "No message provided"}), 400

        message = data["message"].strip()
        if not message:
            return jsonify({"error": "Empty message"}), 400

        # Get metadata context
        metadata = safe_read_json(os.path.join(METADATA_DIR, "metadata.json"))
        
        # Clean and prepare context
        context = []
        for doc in metadata[:3]:  # Limit context to 3 docs
            if isinstance(doc, dict) and "overview_summary" in doc:
                summary = doc["overview_summary"]
                if isinstance(summary, str):
                    summary = summary.encode('utf-8', errors='replace').decode('utf-8')
                    context.append(f"Document '{doc['filename']}': {summary}")

        # Generate response
        try:
            response = await ollama_handler.generate_response(
                prompt=message,
                system_prompt="You are an AI assistant analyzing documents. Be clear and precise.",
                metadata_context=context
            )
            
            if response:
                return jsonify({
                    "status": "success",
                    "response": response.encode('utf-8', errors='replace').decode('utf-8')
                })
            else:
                return jsonify({
                    "status": "error",
                    "message": "No response generated"
                }), 500
                
        except Exception as e:
            app.logger.error(f"Ollama error: {str(e)}")
            return jsonify({
                "status": "error",
                "message": "Processing your request. Please try again."
            }), 503

    except Exception as e:
        app.logger.error(f"Chatbot error: {str(e)}")
        return jsonify({
            "error": str(e)
        }), 500

# -----------------------------
# Static file serving convenience (optional)tional)
# ---------------------------------
@app.route("/static/<path:filename>")
def static_files(filename):
    return send_from_directory("static", filename)

# -----------------------------
# Run app
# -----------------------------
if __name__ == "__main__":
    try:
        app.run(debug=True, port=8004)
    finally:
        driver.close()