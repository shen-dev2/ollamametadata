import requests
import json
import logging
from typing import Optional, Dict, List, Any


class OllamaHandler:
    def __init__(self, base_url: str = "http://localhost:11434", model: str = "llama2"):
        self.base_url = base_url
        self.model = model
        self.context = []
        self.logger = logging.getLogger(__name__)
        
    def _sanitize_text(self, text: str) -> str:
        """Sanitize text to handle Unicode issues"""
        return text.encode('utf-8', errors='replace').decode('utf-8')

    async def generate_response(
        self, 
        prompt: str, 
        system_prompt: Optional[str] = None,
        metadata_context: Optional[List[Dict[str, Any]]] = None
    ) -> str:
        try:
            # Sanitize inputs
            prompt = self._sanitize_text(prompt)
            if system_prompt:
                system_prompt = self._sanitize_text(system_prompt)
            
            # Prepare context from metadata
            context_text = ""
            if metadata_context:
                context_text = "Context from documents:\n"
                for doc in metadata_context:
                    if 'overview_summary' in doc:
                        context_text += f"- {doc['filename']}: {doc['overview_summary'][:200]}...\n"
            
            # Build enhanced prompt
            enhanced_prompt = f"""{context_text}

User Question: {prompt}

Please provide a clear and specific answer based on the available context."""

            headers = {'Content-Type': 'application/json'}
            
            payload = {
                "model": self.model,
                "prompt": enhanced_prompt,
                "system": system_prompt or "You are a helpful AI assistant analyzing documents and answering questions.",
                "context": self.context,
                "stream": False,
                "temperature": 0.7,
                "max_tokens": 500,
                "options": {
                    "num_ctx": 4096,  # Increased context window for Llama 3
                    "temperature": 0.7,
                    "top_p": 0.9,
                    "frequency_penalty": 0.1,
                    "presence_penalty": 0.1
                }
            }
            
            self.logger.debug(f"Sending request to Ollama API with payload: {payload}")
            
            response = requests.post(
                f"{self.base_url}/api/generate",
                headers=headers,
                json=payload,
                timeout=30  # Add timeout
            )
            
            response.raise_for_status()  # Raise exception for bad status codes
            
            result = response.json()
            self.context = result.get('context', [])
            
            return self._sanitize_text(result['response'])
                
        except requests.exceptions.RequestException as e:
            self.logger.error(f"Error making request to Ollama: {str(e)}")
            return f"Error connecting to Ollama: {str(e)}"
        except json.JSONDecodeError as e:
            self.logger.error(f"Error decoding JSON response: {str(e)}")
            return "Error: Invalid response from Ollama"
        except Exception as e:
            self.logger.error(f"Unexpected error: {str(e)}")
            return f"Unexpected error: {str(e)}"

    async def check_model_availability(self) -> bool:
        """Check if the model is available and running"""
        try:
            response = requests.get(
                f"{self.base_url}/api/tags",
                timeout=5
            )
            if response.status_code == 200:
                models = response.json().get("models", [])
                return self.model in [m["name"] for m in models]
            return False
        except Exception as e:
            self.logger.error(f"Error checking model availability: {str(e)}")
            return False