from flask import Blueprint, render_template, jsonify, request, current_app
import os
import json
from modules.ollama_handler import OllamaHandler
import asyncio

bp = Blueprint('user', __name__, url_prefix='/user')
ollama_handler = OllamaHandler()

def safe_read_json(file_path):
    try:
        with open(file_path, 'r', encoding='utf-8', errors='replace') as f:
            return json.load(f)
    except Exception as e:
        current_app.logger.error(f"Error reading JSON: {str(e)}")
        return []

@bp.route('/')
async def user_panel():
    try:
        # Get metadata
        metadata_path = os.path.join(current_app.config['METADATA_DIR'], 'metadata.json')
        metadata = safe_read_json(metadata_path)

        # Process graph data
        graph_summary = await process_graph_data(metadata)
        
        return render_template('user.html', 
                            metadata=metadata,
                            graph_summary=graph_summary)
    except Exception as e:
        current_app.logger.error(f"Error in user panel: {str(e)}")
        return render_template('error.html', error=str(e)), 500

async def process_graph_data(metadata):
    graph_summary = {
        'total_docs': len(metadata),
        'tech_categories': {},
        'domains': {},
        'relationships': [],
        'clusters': []
    }

    try:
        # Process documents
        for doc in metadata:
            if isinstance(doc, dict):
                # Technology categories
                if 'classification' in doc:
                    for tech in doc.get('technologies', []):
                        graph_summary['tech_categories'][tech] = \
                            graph_summary['tech_categories'].get(tech, 0) + 1
                
                # Domain categories
                if 'domain' in doc:
                    domain = doc['domain']
                    graph_summary['domains'][domain] = \
                        graph_summary['domains'].get(domain, 0) + 1

                # Relationships
                if 'relationships' in doc:
                    graph_summary['relationships'].extend(doc['relationships'])

                # Clusters
                if 'cluster' in doc:
                    if doc['cluster'] not in graph_summary['clusters']:
                        graph_summary['clusters'].append(doc['cluster'])

    except Exception as e:
        current_app.logger.error(f"Error processing graph data: {str(e)}")

    return graph_summary

@bp.route('/chat', methods=['POST'])
async def chat():
    try:
        data = request.get_json()
        if not data or 'message' not in data:
            return jsonify({'error': 'No message provided'}), 400

        message = data['message'].strip()
        if not message:
            return jsonify({'error': 'Empty message'}), 400

        # Get context
        metadata = safe_read_json(os.path.join(current_app.config['METADATA_DIR'], 'metadata.json'))
        
        # Generate response
        response = await ollama_handler.generate_response(
            prompt=message,
            system_prompt="You are analyzing technical documents. Be precise and professional.",
            metadata_context=metadata[:3]  # Use top 3 relevant docs
        )
        
        if response:
            return jsonify({
                'status': 'success',
                'response': response
            })
        
        return jsonify({
            'status': 'error',
            'message': 'No response generated'
        }), 500

    except Exception as e:
        current_app.logger.error(f"Chat error: {str(e)}")
        return jsonify({'error': str(e)}), 500