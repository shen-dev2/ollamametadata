from flask import Blueprint, render_template, jsonify, request, current_app
import os
from werkzeug.utils import secure_filename
from modules.neo4j_handler import Neo4jHandler
import json

bp = Blueprint('admin', __name__, url_prefix='/admin')

# Neo4j configuration
NEO4J_URI = "bolt://localhost:7687"
NEO4J_USER = "neo4j"
NEO4J_PASSWORD = "your-password"  # Set this in environment variables

handler = Neo4jHandler(NEO4J_URI, NEO4J_USER, NEO4J_PASSWORD)

@bp.route('/')
def admin_panel():
    try:
        folder_stats = get_folder_stats()
        graph_stats = handler.get_graph_stats()
        return render_template('admin.html', 
                            folder_stats=folder_stats,
                            graph_stats=graph_stats)
    except Exception as e:
        current_app.logger.error(f"Admin panel error: {str(e)}")
        return render_template('error.html', error=str(e)), 500

@bp.route('/upload', methods=['POST'])
async def upload_files():
    try:
        if 'files[]' not in request.files:
            return jsonify({'error': 'No files uploaded'}), 400

        files = request.files.getlist('files[]')
        saved_files = []

        for file in files:
            if file and file.filename:
                filename = secure_filename(file.filename)
                filepath = os.path.join(current_app.config['UPLOAD_FOLDER'], filename)
                file.save(filepath)
                saved_files.append(filename)

        return jsonify({
            'status': 'success',
            'message': f'Successfully uploaded {len(saved_files)} files',
            'files': saved_files
        })

    except Exception as e:
        return jsonify({'error': str(e)}), 500

@bp.route('/process', methods=['POST'])
async def process_documents():
    try:
        # Process documents and build graph
        result = await handler.process_documents()
        return jsonify(result)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@bp.route('/graph/generate', methods=['POST'])
async def generate_graph():
    try:
        result = await handler.generate_graph()
        return jsonify({
            'status': 'success',
            'stats': result['stats'],
            'summary': result['summary']
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

def get_folder_stats():
    upload_dir = current_app.config['UPLOAD_FOLDER']
    files = [f for f in os.listdir(upload_dir) if os.path.isfile(os.path.join(upload_dir, f))]
    return {
        'total_files': len(files),
        'file_types': {'.pdf': len([f for f in files if f.lower().endswith('.pdf')]),
                      '.txt': len([f for f in files if f.lower().endswith('.txt')])},
        'recent_files': files[-5:]  # Last 5 files
    }