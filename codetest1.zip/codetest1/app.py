from flask import Flask, jsonify, render_template, request
import os
import json
import asyncio
import time
import hashlib
import subprocess
from datetime import datetime
import fitz  # PyMuPDF
from langdetect import detect
from neo4j import GraphDatabase
from collections import defaultdict
from modules.metadata_extractors import enrich_text
from modules.neo4j_handler import Neo4jHandler
from modules import metadata_extractors

app = Flask(__name__)

# Paths
ROOT_FOLDER = r"C:\demo1\azurevmollama\VMworkingcode\codetest1\KM_folder"
METADATA_DIR = r"C:\demo1\azurevmollama\VMworkingcode\codetest1\metadata"
SITEMAP_DIR = r"C:\demo1\azurevmollama\VMworkingcode\codetest1\sitemaps"

# Neo4j
NEO4J_URI = "bolt://localhost:7687"
NEO4J_USER = "neo4j"
NEO4J_PASSWORD = "graph@1234"
driver = GraphDatabase.driver(NEO4J_URI, auth=(NEO4J_USER, NEO4J_PASSWORD))
handler = Neo4jHandler(driver)

os.makedirs(SITEMAP_DIR, exist_ok=True)
os.makedirs(METADATA_DIR, exist_ok=True)

# Utility
def infer_tags(path):
    parts = path.replace("\\", "/").split("/")
    return {
        "domain": parts[0] if len(parts) > 0 else "Unknown",
        "region": parts[1] if len(parts) > 1 else "Unknown",
        "client": parts[2] if len(parts) > 2 else "Unknown"
    }

def file_hash(path):
    with open(path, "rb") as f:
        return hashlib.md5(f.read()).hexdigest()

def detect_language(text):
    try:
        return detect(text)
    except:
        return "unknown"

def generate_quick_overview(text, max_chars=500):
    return text.strip().replace("\n", " ")[:max_chars]

# Sitemap builder
def build_sitemap(root_folder):
    entries = []
    for dirpath, _, filenames in os.walk(root_folder):
        for fname in filenames:
            ext = os.path.splitext(fname)[1].lower()
            if ext != ".pdf":
                continue
            full_path = os.path.join(dirpath, fname)
            rel_path = os.path.relpath(full_path, root_folder)
            tags = infer_tags(rel_path)
            stat = os.stat(full_path)
            try:
                with fitz.open(full_path) as doc:
                    page_count = doc.page_count
                    text = doc[0].get_text("text") if page_count > 0 else ""
            except:
                page_count = 0
                text = ""
            entries.append({
                "id": file_hash(full_path)[:12],
                "filename": fname,
                "absolute_path": full_path,
                "relative_path": rel_path,
                "extension": ext,
                "domain": tags["domain"],
                "region": tags["region"],
                "client": tags["client"],
                "file_size_bytes": stat.st_size,
                "last_modified": datetime.fromtimestamp(stat.st_mtime).isoformat(),
                "page_count": page_count,
                "quick_overview": generate_quick_overview(text)
            })
    return entries

# PDF extractors
def extract_pdf_text(file_path):
    text_chunks = []
    with fitz.open(file_path) as doc:
        for page in doc:
            text_chunks.append(page.get_text("text"))
    return "\n".join(text_chunks)

def extract_pdf_metadata(file_path):
    props = {}
    try:
        stat = os.stat(file_path)
        props["file_size_bytes"] = stat.st_size
        props["created_time"] = datetime.fromtimestamp(stat.st_ctime).isoformat()
        props["modified_time"] = datetime.fromtimestamp(stat.st_mtime).isoformat()
    except Exception as e:
        props["fs_meta_error"] = str(e)

    try:
        with fitz.open(file_path) as doc:
            props["page_count"] = doc.page_count
            props["pdf_metadata"] = doc.metadata or {}
    except Exception as e:
        props["pdf_meta_error"] = str(e)

    return props

async def process_pdf(entry, root_folder, preview_chars=1500):
    full_path = os.path.join(root_folder, entry["relative_path"])
    start = time.time()
    try:
        text = await asyncio.to_thread(extract_pdf_text, full_path)
        props = await asyncio.to_thread(extract_pdf_metadata, full_path)
        lang = detect_language(text)
        hash_val = file_hash(full_path)
        enrichment = await metadata_extractors.enrich_text(text, props.get("page_count", 0))
    except Exception as e:
        return {"error": str(e), "filename": entry["filename"]}

    elapsed = round(time.time() - start, 3)

    return {
        "id": hash_val[:12],
        "filename": entry["filename"],
        "relative_path": entry["relative_path"],
        "extension": entry["extension"],
        "tags": {
            "domain": entry["domain"],
            "region": entry["region"],
            "client": entry["client"]
        },
        "file_size_bytes": props.get("file_size_bytes"),
        "last_modified": props.get("modified_time"),
        "page_count": props.get("page_count"),
        "content_length": len(text),
        "pdf_metadata": props.get("pdf_metadata"),
        "hash": hash_val,
        "language": lang,
        "ingested_at": datetime.utcnow().isoformat(),
        "content_preview": text[:preview_chars],
        "overview_summary": enrichment["content_summary"]["summary"],
        "content_summary": enrichment["content_summary"],
        "classification": enrichment["classification"],
        "industry_tags": enrichment["industry_tags"],
        "entities": enrichment["entities"],
        "extraction_time_sec": elapsed
    }

async def process_all_pdfs(sitemap, root_folder):
    tasks = [process_pdf(entry, root_folder) for entry in sitemap]
    return await asyncio.gather(*tasks)

# UTF-8 safe llama3 helper
def ask_llama(prompt: str) -> str:
    """
    Calls Ollama to run llama3 and returns the model response,
    encoding input and decoding output as UTF-8 to avoid charmap errors.
    """
    try:
        proc = subprocess.run(
            ["ollama", "run", "llama3"],
            input=prompt.encode("utf-8"),
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE
        )
        return proc.stdout.decode("utf-8", errors="replace").strip()
    except Exception as e:
        return f"Error calling Ollama: {e}"

# Flask routes
@app.route("/")
def home():
    return render_template("index.html")

@app.route("/ingest", methods=["GET"])
def ingest():
    sitemap = build_sitemap(ROOT_FOLDER)
    sitemap_path = os.path.join(SITEMAP_DIR, "sitemap.json")
    with open(sitemap_path, "w", encoding="utf-8") as f:
        json.dump(sitemap, f, indent=2, ensure_ascii=False)

    results = asyncio.run(process_all_pdfs(sitemap, ROOT_FOLDER))
    metadata_path = os.path.join(METADATA_DIR, "metadata.json")
    with open(metadata_path, "w", encoding="utf-8") as f:
        json.dump(results, f, indent=2, ensure_ascii=False)

    for doc in results:
        if "id" in doc and "filename" in doc:
            handler.create_document_graph(doc)

    preview = json.dumps(results[:1], indent=2, ensure_ascii=False)
    return render_template(
        "results.html",
        files_processed=len(results),
        sitemap_file=sitemap_path,
        metadata_file=metadata_path,
        metadata_preview=preview
    )

@app.route("/view_sitemap")
def view_sitemap():
    path = os.path.join(SITEMAP_DIR, "sitemap.json")
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    return jsonify(data)

@app.route("/view_metadata")
def view_metadata():
    path = os.path.join(METADATA_DIR, "metadata.json")
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    return jsonify(data)

@app.route("/view_graph")
def view_graph():
    with driver.session() as session:
        result = session.run("""
            MATCH (a)-[r]->(b)
            RETURN a, r, b LIMIT 100
        """)
        nodes, edges = [], []
        seen = set()

        def node_color(label):
            colors = {
                "Document": "#1f77b4",
                "Client": "#2ca02c",
                "Region": "#ff7f0e",
                "Domain": "#9467bd",
                "Industry": "#8c564b",
                "Technology": "#17becf",
                "Partner": "#d62728",
                "Product": "#bcbd22"
            }
            return colors.get(label, "#7f7f7f")

        for record in result:
            a, r, b = record["a"], record["r"], record["b"]

            if a.id not in seen:
                label = list(a.labels)[0] if a.labels else "Node"
                nodes.append({
                    "id": a.id,
                    "label": label,
                    "title": dict(a),
                    "color": node_color(label)
                })
                seen.add(a.id)

            if b.id not in seen:
                label = list(b.labels)[0] if b.labels else "Node"
                nodes.append({
                    "id": b.id,
                    "label": label,
                    "title": dict(b),
                    "color": node_color(label)
                })
                seen.add(b.id)

            edges.append({
                "from": a.id,
                "to": b.id,
                "label": r.type
            })

    return render_template(
        "graph.html",
        nodes=json.dumps(nodes),
        edges=json.dumps(edges)
    )
from collections import defaultdict

def _render_classification_tables(docs):
    """
    Build relation summary + classification tables for:
      • Group Priority
      • Sector
      • Service Offering
    Then render graph_summary.html with that data.
    """
    # 1) Neo4j relation counts
    rel_lines = []
    with driver.session() as sess:
        result = sess.run("""
            MATCH ()-[r]->()
            RETURN type(r) AS rel_name, count(r) AS cnt
        """)
        for rec in result:
            rel_lines.append(f"{rec['rel_name']}: {rec['cnt']}")
    rel_summary = (
        "Graph Relations:\n" + "\n".join(rel_lines)
    ) if rel_lines else "Graph Relations: (none found)"

    # 2) Tally classifications
    group_counts   = defaultdict(int)
    sector_counts  = defaultdict(int)
    service_counts = defaultdict(int)

    for d in docs:
        cls = d.get("classification", {}) or {}
        grp    = cls.get("group_priority", "Unknown")
        sect   = cls.get("sector", "Unknown")
        svcs   = cls.get("service_offerings", [])
        # ensure list
        if not isinstance(svcs, (list, tuple)):
            svcs = [svcs or "Unknown"]

        group_counts[grp] += 1
        sector_counts[sect] += 1
        for svc in svcs:
            service_counts[svc] += 1

    # 3) Prepare lists for template
    group_summary = [
        {"name": name, "count": cnt}
        for name, cnt in sorted(group_counts.items(), key=lambda x: -x[1])
    ]
    sector_summary = [
        {"name": name, "count": cnt}
        for name, cnt in sorted(sector_counts.items(), key=lambda x: -x[1])
    ]
    service_summary = [
        {"name": name, "count": cnt}
        for name, cnt in sorted(service_counts.items(), key=lambda x: -x[1])
    ]

    # 4) Render the template with all four contexts
    return render_template(
        "graph_summary.html",
        rel_summary=rel_summary,
        group_summary=group_summary,
        sector_summary=sector_summary,
        service_summary=service_summary
    )


@app.route("/graph_summary")
def graph_summary():
    # load metadata
    meta_path = os.path.join(METADATA_DIR, "metadata.json")
    with open(meta_path, "r", encoding="utf-8") as f:
        docs = json.load(f)

    # check if we already have classification fields
    has_cls = all(
        isinstance(d.get("classification"), dict)
        and d["classification"].get("group_priority")
        for d in docs
    )

    if has_cls:
        # use the existing summary logic (tables)
        return _render_classification_tables(docs)
    else:
        # fallback: build a prompt for Llama3
        # include filenames + one-line overviews
        prompt = "Summarize the following documents by group priority, sector, and service offering. " \
                 "List each category and how many files belong:\n\n"
        for d in docs:
            prompt += f"- {d['filename']}: {d.get('overview_summary','')[:100]}...\n"
        prompt += "\nFormat your answer as:\n" \
                  "Group Priority:\n  High: X files\n  Medium: Y files\nSector:\n  Insurance: A files\n  Manufacturing: B files\nService Offering:\n  Consulting: M files\n  Implementation: N files\n"

        summary_text = ask_llama(prompt)
        return render_template("graph_summary_fallback.html", summary=summary_text)

@app.route("/chat", methods=["GET", "POST"])
def chat():
    user_msg = None
    bot_resp = None

    if request.method == "POST":
        user_msg = request.form.get("message", "").strip()

        # Load metadata.json
        meta_path = os.path.join(METADATA_DIR, "metadata.json")
        try:
            with open(meta_path, "r", encoding="utf-8") as f:
                docs = json.load(f)
        except Exception as e:
            bot_resp = f"Could not load metadata: {e}"
        else:
            # Build document-overview context
            doc_context = ""
            for d in docs:
                doc_context += (
                    f"Filename: {d['filename']}\n"
                    f"Overview: {d.get('overview_summary','(no summary)')}\n\n"
                )

            # Query Neo4j for relation counts
            rel_summary = ""
            with driver.session() as sess:
                result = sess.run("""
                    MATCH ()-[r]->()
                    RETURN type(r) AS rel_name, count(r) AS cnt
                """)
                lines = [f"{rec['rel_name']}: {rec['cnt']}" for rec in result]
                rel_summary = (
                    "Graph relations:\n" +
                    "\n".join(lines) + "\n\n"
                ) if lines else "Graph relations: (none found)\n\n"

            # Aggregate entities & industry tags
            all_entities = set()
            all_industries = set()
            for d in docs:
                all_entities.update(d.get("entities", []))
                all_industries.update(d.get("industry_tags", []))

            ent_summary = (
                f"Entities recognized: {', '.join(sorted(all_entities))}\n"
                f"Industry tags: {', '.join(sorted(all_industries))}\n\n"
            )

            # Compose combined prompt
            prompt = (
                "You are a knowledgeable assistant.  Use the following context:\n\n"
                f"{doc_context}"
                f"{rel_summary}"
                f"{ent_summary}"
                f"User Question: {user_msg}\n\n"
                "Answer concisely, reference filenames or relations if relevant."
            )

            # Call llama3
            bot_resp = ask_llama(prompt)

    return render_template(
        "chat.html",
        user_msg=user_msg,
        bot_resp=bot_resp
    )

if __name__ == "__main__":
    app.run(debug=True, port=5007)
    driver.close()
