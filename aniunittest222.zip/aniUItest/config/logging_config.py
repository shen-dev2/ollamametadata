import logging
import os
from config.logging_config import setup_logging
from modules.ollama_handler import OllamaHandler

# Setup logging
setup_logging()

# Initialize Ollama handler with Llama 3
ollama_handler = OllamaHandler(model="llama2:13b")

# Verify model availability at startup
@app.before_first_request
async def verify_model():
    if not await ollama_handler.check_model_availability():
        app.logger.error("Llama model not available! Please ensure Ollama is running with the correct model.")

def setup_logging():
    log_dir = "logs"
    os.makedirs(log_dir, exist_ok=True)
    
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(os.path.join(log_dir, 'app.log'), encoding='utf-8'),
            logging.StreamHandler()
        ]
    )

# Test code
async def test_chat():
    response = await ollama_handler.generate_response(
        prompt="What can you tell me about this document?",
        metadata_context=[{"filename": "test.pdf", "overview_summary": "This is a test document"}]
    )
    print(response)