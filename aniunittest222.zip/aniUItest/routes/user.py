from flask import Blueprint, render_template, jsonify, request, current_app
from utils.file_helpers import safe_read_json
from modules.ollama_handler import OllamaHandler
import os

bp = Blueprint('user', __name__)
ollama_handler = OllamaHandler()

@bp.route('/user')
def user_panel():
    try:
        metadata_path = os.path.join(current_app.config['METADATA_DIR'], "metadata.json")
        metadata = safe_read_json(metadata_path) or []
        
        # Ensure each document has required fields
        for doc in metadata:
            if 'quick_overview' not in doc:
                doc['quick_overview'] = doc.get('overview_summary', 'No overview available')
            
        return render_template('user.html', metadata=metadata)
    except Exception as e:
        current_app.logger.error(f"Error in user panel: {str(e)}")
        return render_template('error.html', error=str(e)), 500

@bp.route('/chat', methods=['POST'])
async def chat():
    if not request.is_json:
        return jsonify({'error': 'Content-Type must be application/json'}), 400

    try:
        data = request.get_json()
        message = data.get('query', '').strip()
        
        if not message:
            return jsonify({'error': 'Empty message'}), 400

        metadata_path = os.path.join(current_app.config['METADATA_DIR'], "metadata.json")
        metadata = safe_read_json(metadata_path) or []

        response = await ollama_handler.generate_response(
            prompt=message,
            metadata_context=metadata
        )

        return jsonify({'status': 'success', 'response': response})
    except Exception as e:
        current_app.logger.error(f"Chat error: {str(e)}")
        return jsonify({'error': str(e)}), 500