import json

def safe_read_file(file_path, encoding='utf-8'):
    """Safely read a file with proper encoding handling."""
    try:
        with open(file_path, 'r', encoding=encoding) as f:
            return f.read()
    except UnicodeDecodeError:
        with open(file_path, 'r', encoding=encoding, errors='replace') as f:
            return f.read()

def safe_read_json(file_path, encoding='utf-8'):
    """Safely read a JSON file with proper encoding handling."""
    try:
        with open(file_path, 'r', encoding=encoding) as f:
            return json.load(f)
    except UnicodeDecodeError:
        with open(file_path, 'r', encoding=encoding, errors='replace') as f:
            return json.load(f)
    except Exception as e:
        print(f"Error reading JSON from {file_path}: {str(e)}")
        return None